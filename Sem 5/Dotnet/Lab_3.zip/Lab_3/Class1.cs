﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_3
{
    public class Class1
    {
        public void Add(int a, int b)
        {
            Console.WriteLine(a + b);
        }

        public void Add(float a, float b)
        {
            Console.WriteLine(a + b);
        }
    }
}
