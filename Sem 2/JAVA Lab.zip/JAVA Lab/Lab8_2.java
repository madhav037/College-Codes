package vsJAVA;public class Lab8_2 {
}
