package vsJAVA;

import java.util.Scanner;

public class Lab2_1 {
    public static void main(String[] args){
        float a;
        System.out.print("Enter length in meters : ");
        Scanner var1=new Scanner(System.in);//3.28
        a = var1.nextFloat();
        System.out.println(a*3.2804);
    }
}
