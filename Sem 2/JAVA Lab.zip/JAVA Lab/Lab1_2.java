package vsJAVA;

public class Lab1_2{
    public static void main(String[] arg){

    }
}