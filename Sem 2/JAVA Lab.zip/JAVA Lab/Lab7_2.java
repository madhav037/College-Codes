package vsJAVA;

public class Lab7_2 {
    static{
        System.out.println("Hello before main");
    }
    public static void main(String[] args) {
        System.out.println("Hello after main");
    }
}